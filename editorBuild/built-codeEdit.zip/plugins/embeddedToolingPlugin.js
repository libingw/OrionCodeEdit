/*

 Copyright (c) 2012 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2011, 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2012, 2013 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10/.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2015 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2012, 2015 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2012 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 


 Copyright (c) 2012 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).


 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors: IBM Corporation - initial API and implementation

 Copyright (c) 2014 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2015 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2013 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made
 available under the terms of the Eclipse Public License v1.0
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html).

 Contributors:
     IBM Corporation - initial API and implementation

 Copyright (c) 2010, 2012 IBM Corporation and others.
 All rights reserved. This program and the accompanying materials are made 
 available under the terms of the Eclipse Public License v1.0 
 (http://www.eclipse.org/legal/epl-v10.html), and the Eclipse Distribution 
 License v1.0 (http://www.eclipse.org/org/documents/edl-v10.html). 

 Contributors: IBM Corporation - initial API and implementation
 RequireJS i18n 2.0.4 Copyright (c) 2010-2012, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/requirejs/i18n for details
*/
(function(x,e){"function"===typeof define&&define.amd?define([],e):(x.orion=x.orion||{},x.orion.webtools=x.orion.webtools||{},x.orion.webtools.embeddedTooling=e())})(this,function(){var x,e;(function(d){function c(a,b){var c,d,h,n,f,g,w,t,k,r=b&&b.split("/"),e=l.map,p=e&&e["*"]||{};if(a&&"."===a.charAt(0))if(b){r=r.slice(0,r.length-1);a=r.concat(a.split("/"));for(t=0;t<a.length;t+=1)if(c=a[t],"."===c)a.splice(t,1),t-=1;else if(".."===c)if(1===t&&(".."===a[2]||".."===a[0]))break;else 0<t&&(a.splice(t-
1,2),t-=2);a=a.join("/")}else 0===a.indexOf("./")&&(a=a.substring(2));if((r||p)&&e){c=a.split("/");for(t=c.length;0<t;t-=1){d=c.slice(0,t).join("/");if(r)for(k=r.length;0<k;k-=1)if(h=e[r.slice(0,k).join("/")])if(h=h[d]){n=h;f=t;break}if(n)break;!g&&(p&&p[d])&&(g=p[d],w=t)}!n&&g&&(n=g,f=w);n&&(c.splice(0,f,n),a=c.join("/"))}return a}function a(a,b){return function(){return p.apply(d,u.call(arguments,0).concat([a,b]))}}function b(a){return function(b){return c(b,a)}}function f(a){return function(b){g[a]=
b}}function h(a){if(y.call(m,a)){var b=m[a];delete m[a];r[a]=!0;n.apply(d,b)}if(!y.call(g,a)&&!y.call(r,a))throw Error("No "+a);return g[a]}function s(a){var b,c=a?a.indexOf("!"):-1;-1<c&&(b=a.substring(0,c),a=a.substring(c+1,a.length));return[b,a]}function w(a){return function(){return l&&l.config&&l.config[a]||{}}}var n,p,k,q,g={},m={},l={},r={},y=Object.prototype.hasOwnProperty,u=[].slice;k=function(a,d){var n,f=s(a),g=f[0];a=f[1];g&&(g=c(g,d),n=h(g));g?a=n&&n.normalize?n.normalize(a,b(d)):c(a,
d):(a=c(a,d),f=s(a),g=f[0],a=f[1],g&&(n=h(g)));return{f:g?g+"!"+a:a,n:a,pr:g,p:n}};q={require:function(b){return a(b)},exports:function(a){var b=g[a];return"undefined"!==typeof b?b:g[a]={}},module:function(a){return{id:a,uri:"",exports:g[a],config:w(a)}}};n=function(b,c,n,w){var e,p,s,l,u=[],t;w=w||b;if("function"===typeof n){c=!c.length&&n.length?["require","exports","module"]:c;for(l=0;l<c.length;l+=1)if(s=k(c[l],w),p=s.f,"require"===p)u[l]=q.require(b);else if("exports"===p)u[l]=q.exports(b),t=
!0;else if("module"===p)e=u[l]=q.module(b);else if(y.call(g,p)||y.call(m,p)||y.call(r,p))u[l]=h(p);else if(s.p)s.p.load(s.n,a(w,!0),f(p),{}),u[l]=g[p];else throw Error(b+" missing "+p);c=n.apply(g[b],u);if(b)if(e&&e.exports!==d&&e.exports!==g[b])g[b]=e.exports;else if(c!==d||!t)g[b]=c}else b&&(g[b]=n)};x=p=function(a,b,c,f,g){if("string"===typeof a)return q[a]?q[a](b):h(k(a,b).f);a.splice||(l=a,b.splice?(a=b,b=c,c=null):a=d);b=b||function(){};"function"===typeof c&&(c=f,f=g);f?n(d,a,b,c):setTimeout(function(){n(d,
a,b,c)},4);return p};p.config=function(a){l=a;return p};e=function(a,b,c){b.splice||(c=b,b=[]);!y.call(g,a)&&!y.call(m,a)&&(m[a]=[a,b,c])};e.amd={jQuery:!0}})();e("almond",function(){});(function(d,c){"function"===typeof e&&e.amd?e("orion/Deferred",c):"object"===typeof exports?module.exports=c():(d.orion=d.orion||{},d.orion.Deferred=c())})(this,function(){function d(){for(var a;a=f.shift();)a();h=!1}function c(a){f.push(a);h||(h=!0,e())}function a(a){return function(b){a(b)}}function b(){function d(){for(var b;b=
s.shift();){var c=b.deferred,n="fulfilled"===g?"resolve":"reject";b=b[n];if("function"===typeof b)try{var h=b(e),f=h&&("object"===typeof h||"function"===typeof h)&&h.then;if("function"===typeof f)if(h===c.promise)c.reject(new TypeError);else{var p=h.cancel;"function"===typeof p?c._parentCancel=p.bind(h):delete c._parentCancel;f.call(h,a(c.resolve),a(c.reject),a(c.progress))}else c.resolve(h)}catch(k){c.reject(k)}else c[n](e)}}function n(a){delete l._parentCancel;g="rejected";e=a;s.length&&c(d)}function h(a){function f(a){return function(b){(!g||
"assumed"===g)&&a(b)}}delete l._parentCancel;try{var k=a&&("object"===typeof a||"function"===typeof a)&&a.then;if("function"===typeof k)if(a===l)n(new TypeError);else{g="assumed";var v=a&&a.cancel;if("function"!==typeof v){var z=new b;a=z.promise;try{k(z.resolve,z.reject,z.progress)}catch(F){z.reject(F)}v=a.cancel;k=a.then}e=a;k.call(a,f(h),f(n));l._parentCancel=v.bind(a)}else g="fulfilled",e=a,s.length&&c(d)}catch(x){f(n)(x)}}function f(){var a=l._parentCancel;a?(delete l._parentCancel,a()):g||(a=
Error("Cancel"),a.name="Cancel",n(a))}var e,g,s=[],l=this;this.resolve=function(a){g||h(a);return l};this.reject=function(a){g||n(a);return l};this.progress=function(a){g||s.forEach(function(b){if(b.progress)try{b.progress(a)}catch(c){}});return l.promise};this.cancel=function(){l._parentCancel?setTimeout(f,0):f();return l};this.then=function(a,h,n){var f=new b;f._parentCancel=l.promise.cancel;s.push({resolve:a,reject:h,progress:n,deferred:f});("fulfilled"===g||"rejected"===g)&&c(d);return f.promise};
this.promise={then:l.then,cancel:l.cancel}}var f=[],h=!1,e=function(){if("undefined"!==typeof process&&"function"===typeof process.nextTick){var a=process.nextTick;return function(){a(d)}}if("function"===typeof MutationObserver){var b=document.createElement("div");(new MutationObserver(d)).observe(b,{attributes:!0});return function(){b.setAttribute("class","_tick")}}return function(){setTimeout(d,0)}}();b.all=function(a,c){function d(a,b){e||(g[a]=b,0===--f&&s.resolve(g))}function h(a,b){if(!e){if(c)try{d(a,
c(b));return}catch(f){b=f}s.reject(b)}}var f=a.length,g=[],e=!1,s=new b;s.then(void 0,function(){e=!0;a.forEach(function(a){a.cancel&&a.cancel()})});0===f?s.resolve(g):a.forEach(function(a,b){a.then(d.bind(void 0,b),h.bind(void 0,b))});return s.promise};b.when=function(a,c,d,h){var f;a&&"function"===typeof a.then||(f=new b,f.resolve(a),a=f.promise);return a.then(c,d,h)};return b});(function(d,c){"function"===typeof e&&e.amd?e("orion/plugin",["orion/Deferred"],c):"object"===typeof exports?module.exports=
c(x("orion/Deferred")):(d.orion=d.orion||{},d.orion.PluginProvider=c(d.orion.Deferred))})(this,function(d){function c(a,b){this.__objectId=a;this.__methods=b}return function(a){function b(a,b){if(b=b||A)"undefined"===typeof ArrayBuffer&&(a=JSON.stringify(a)),b===self||C?b.postMessage(a):b.postMessage(a,"*")}function f(){var a=(new Date).getTime();E&&4E3>a-E||(E=a,b({method:"loading"}),"undefined"!==typeof localStorage&&localStorage.pluginLogging&&console.log("heartbeat("+((new Date).getTime()-G)+
"ms)\x3d"+self.location))}function h(){var a=[];Object.keys(x).forEach(function(b){var c=x[b];a.push({serviceId:b,names:c.names,methods:c.methods,properties:c.properties})});return{headers:g||{},services:a}}function e(a,b){if(b&&b instanceof XMLHttpRequest){var c,d;try{c=b.status,d=b.statusText}catch(h){c=0,d=""}return{status:c||0,statusText:d}}return b}function w(a){var b=a?JSON.parse(JSON.stringify(a,e)):a;a instanceof Error&&(b.__isError=!0,b.message=b.message||a.message,b.name=b.name||a.name);
return b}function n(a,b){b=b||A;if(!b)return(new d).reject(Error("plugin not connected"));a.id=String(l++);var h=new d;v[a.id]=h;h.then(null,function(c){m&&(c instanceof Error&&"Cancel"===c.name)&&B({requestId:a.id,method:"cancel",params:c.message?[c.message]:[]},b)});var f=Object.prototype.toString;a.params.forEach(function(b,d){if("[object Object]"===f.call(b)&&!(b instanceof c)){var n,g;for(n in b)"[object Function]"===f.call(b[n])&&(g=g||[],g.push(n));if(g){var e=r++;z[e]=b;n=function(){delete z[e]};
h.then(n,n);a.params[d]=new c(e,g)}}});B(a,b);return h.promise}function p(a,b,c){a||0===a?B({id:a,result:null,error:b},c):console.log(b)}function k(a,b,c,d,h){d.forEach(function(a,b){if(a&&"undefined"!==typeof a.__objectId){var c={};a.__methods.forEach(function(b){c[b]=function(){return n({objectId:a.__objectId,method:b,params:Array.prototype.slice.call(arguments)},h)}});d[b]=c}});var f="undefined"===typeof a?null:{id:a,result:null,error:null};try{var g=c.apply(b,d);f&&(g&&"function"===typeof g.then?
(u[a]=g,g.then(function(b){delete u[a];f.result=b;B(f,h)},function(b){u[a]&&(delete u[a],f.error=w(b),B(f,h))},function(){B({responseId:a,method:"progress",params:Array.prototype.slice.call(arguments)},h)})):(f.result=g,B(f,h)))}catch(e){f&&(f.error=w(e),B(f,h))}}function q(a,b){if(C||!(a.source!==A&&"undefined"!==typeof window)){var c=a.data,c="string"!==typeof c?c:JSON.parse(c);try{if(c.method){var d=c.method,h=c.params||[];if("serviceId"in c){var f=x[c.serviceId];f||p(c.id,"service not found",
b);f=f.implementation;d in f?k(c.id,f,f[d],h,b):p(c.id,"method not found",b)}else if("objectId"in c){var n=z[c.objectId];n||p(c.id,"object not found",b);!d in n?k(c.id,n,n[d],h,b):p(c.id,"method not found",b)}else if("requestId"in c){var g=u[c.requestId];g&&("cancel"===d&&g.cancel)&&g.cancel.apply(g,h)}else if("responseId"in c){var e=v[c.responseId];e&&("progress"===d&&e.progress)&&e.progress.apply(e,h)}else throw Error("Bad method: "+c.method);}else{var s=v[String(c.id)];delete v[String(c.id)];c.error?
s.reject(c.error):s.resolve(c.result)}}catch(w){console.log("Plugin._messageHandler "+w)}}}var g=a,m=!1,l=0,r=0,y=0,u={},v={},z={},x={},D=[],C=!1,A=null;"undefined"===typeof window?self.postMessage?A=self:C=!0:window!==window.parent?A=window.parent:null!==window.opener&&(A=window.opener);var B=b,E,G=(new Date).getTime();f();C&&self.addEventListener("connect",function(a){var c=a.ports[0];D.push(c);m?(a={method:"plugin",params:[h()]},b(a,c)):f();c.addEventListener("message",function(a){q(a,c)});c.start()});
this.updateHeaders=function(a){if(m)throw Error("Cannot update headers. Plugin Provider is connected");g=a};this.registerServiceProvider=this.registerService=function(a,b,c){if(m)throw Error("Cannot register service. Plugin Provider is connected");"string"===typeof a?a=[a]:Array.isArray(a)||(a=[]);var d=null,h=[];for(d in b)"function"===typeof b[d]&&h.push(d);x[y++]={names:a,methods:h,implementation:b,properties:c||{},listeners:{}};f()};this.connect=function(a,c){if(!m){var d={method:"plugin",params:[h()]};
if(!C){if(!A){c&&c("No valid plugin target");return}addEventListener("message",q,!1);b(d)}D.forEach(function(a){b(d,a)});m=!0}a&&a()};this.disconnect=function(){m&&(removeEventListener("message",q),D.forEach(function(a){a.close()}),A=D=null,m=!1)}}});e("plugins/languages/arduino/arduinoPlugin",["orion/plugin"],function(d){function c(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-arduino","extends":"text/x-csrc",name:"Arduino",extension:["ino","pde"]}]})}return{connect:function(){var a=
new d({name:"Orion Arduino Tool Support",version:"1.0",description:"This plugin provides Arduino tools support for Orion."});c(a);a.connect()},registerServiceProviders:c}});e("orion/editor/stylers/lib/syntax",[],function(){return{id:"orion.lib",grammars:[{id:"orion.lib",repository:{brace_open:{match:"{",name:"punctuation.section.block.begin"},brace_close:{match:"}",name:"punctuation.section.block.end"},bracket_open:{match:"\\[",name:"punctuation.section.bracket.begin"},bracket_close:{match:"\\]",
name:"punctuation.section.bracket.end"},parenthesis_open:{match:"\\(",name:"punctuation.section.parens.begin"},parenthesis_close:{match:"\\)",name:"punctuation.section.parens.end"},operator:{match:"(\\+|-|!|\x3d|\x3e|\x3c|\x26|(\\|\\|))+",name:"punctuation.operator"},doc_block:{begin:{match:"/\\*\\*",literal:"/**"},end:{match:"\\*/",literal:"*/"},name:"comment.block.documentation",patterns:[{match:"@(?:(?!\\*/)\\S)*",name:"meta.documentation.annotation"},{match:"\x3c[^\\s\x3e]*\x3e",name:"meta.documentation.tag"},
{match:"(\\b)(TODO)(\\b)(((?!\\*/).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.block"}}}]},number_decimal:{match:"\\b-?(?:\\.\\d+|\\d+\\.?\\d*)(?:[eE][+-]?\\d+)?\\b",name:"constant.numeric.number"},number_hex:{match:"\\b0[xX][0-9A-Fa-f]+\\b",name:"constant.numeric.hex"},string_doubleQuote:{match:'"(?:\\\\.|[^"])*"?',name:"string.quoted.double"},string_singleQuote:{match:"'(?:\\\\.|[^'])*'?",name:"string.quoted.single"},todo_comment_singleLine:{match:"(\\b)(TODO)(\\b)(.*)",
name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.line"}}}}},{id:"orion.c-like",repository:{comment_singleLine:{match:{match:"//.*",literal:"//"},name:"comment.line.double-slash",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},comment_block:{begin:{match:"/\\*",literal:"/*"},end:{match:"\\*/",literal:"*/"},name:"comment.block",patterns:[{match:"(\\b)(TODO)(\\b)(((?!\\*/).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},
4:{name:"comment.block"}}}]}}}],keywords:[]}});e("orion/editor/stylers/text_x-csrc/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="auto break case char const continue default double do else enum extern float for goto if inline int long register return short signed sizeof static struct switch typedef union unsigned void volatile while _Bool _Complex _Imaginary".split(" "),a="define elif else endif error ifdef ifndef if include line pragma undef".split(" "),b=[];b.push.apply(b,d.grammars);
b.push({id:"orion.c",contentTypes:["text/x-csrc","text/x-c"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_singleLine"},{include:"orion.lib#doc_block"},{include:"orion.c-like#comment_block"},{include:"#directive"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},
{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.c"}],repository:{directive:{match:"#\\s*(?:"+a.join("|")+")\\b[^$]*",name:"meta.preprocessor.c"}}});return{id:b[b.length-1].id,grammars:b,keywords:c.concat(a)}});e("plugins/languages/c/cPlugin",["orion/plugin","orion/editor/stylers/text_x-csrc/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-csrc",
"extends":"text/plain",name:"C",extension:["c","h"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion C Tool Support",version:"1.0",description:"This plugin provides C tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-c__src/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="alignas alignof asm and_eq and auto bitand bitor bool break case catch char16_t char32_t char class compl constexpr const_cast const continue decltype default delete double do dynamic_cast else enum explicit export extern false float for friend goto if inline int long mutable namespace new noexcept not_eq not nullptr operator or_eq or private protected public register reinterpret_cast return short signed sizeof static_assert static_cast static struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while xor_eq xor _Bool _Complex _Imaginary".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.cpp",contentTypes:["text/x-c++src","text/x-c++"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_singleLine"},{include:"orion.lib#doc_block"},{include:"orion.c-like#comment_block"},{include:"#directive"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},
{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.cpp"}],repository:{directive:{match:"#\\s*(?:define|elif|else|endif|error|ifdef|ifndef|if|include|line|pragma|undef)\\b[^$]*",name:"meta.preprocessor.cpp"}}});return{id:a[a.length-1].id,grammars:a,keywords:c}});e("plugins/languages/cpp/cppPlugin",["orion/plugin","orion/editor/stylers/text_x-c__src/syntax"],
function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-c++src","extends":"text/plain",name:"C++",extension:["cpp","hpp"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion C++ Tool Support",version:"1.0",description:"This plugin provides C++ tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-csharp/syntax",
["orion/editor/stylers/lib/syntax"],function(d){var c="abstract as base bool break byte by case catch char checked class const continue decimal default delegate descending double do else enum event explicit extern false finally fixed float foreach for from goto group if implicit int interface internal into in is lock long namespace new null object operator orderby out override params private protected public readonly ref return sbyte sealed select short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using var virtual volatile void while where yield".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.csharp",contentTypes:["text/x-csharp"],patterns:[{match:"^\\s*#(?:define|elif|else|endif|endregion|error|if|line|pragma checksum|pragma warning|pragma|region|undef|warning)\\b[^$]*",name:"meta.preprocessor.csharp"},{include:"#string_verbatim"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"#doc_line"},{include:"orion.c-like#comment_singleLine"},{include:"#doc_block"},{include:"orion.c-like#comment_block"},
{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.csharp"}],repository:{doc_block:{begin:{match:"/\\*\\*",literal:"/**"},end:{match:"\\*/",literal:"*/"},name:"comment.block.documentation.csharp",
patterns:[{match:"\x3c[^\\s\x3e]*\x3e",name:"meta.documentation.tag"},{match:"(\\b)(TODO)(\\b)(((?!\\*/).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.block"}}}]},doc_line:{match:{match:"// /.*",literal:"// /"},name:"comment.line.documentation.csharp",patterns:[{match:"\x3c[^\\s\x3e]*\x3e",name:"meta.documentation.tag"},{include:"orion.lib#todo_comment_singleLine"}]},string_verbatim:{begin:'@"',end:'^(?:""|[^"])*"(?!")',name:"string.quoted.verbatim.csharp"}}});
return{id:a[a.length-1].id,grammars:a,keywords:c}});e("orion/editor/stylers/application_xml/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c=[];c.push.apply(c,d.grammars);c.push({id:"orion.xml",contentTypes:["application/xml","application/xhtml+xml"],patterns:[{include:"#comment"},{include:"#doctype"},{include:"#xmlDeclaration"},{include:"#tag"},{include:"#ampersandEscape"}],repository:{ampersandEscape:{match:"\x26lt;|\x26gt;|\x26amp;",name:"constant.character"},comment:{begin:{match:"\x3c!--",
literal:"\x3c!--"},end:{match:"--\x3e",literal:"--\x3e"},name:"comment.block.xml",patterns:[{match:"(\\b)(TODO)(\\b)(((?!--\x3e).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.line"}}}]},doctype:{begin:"\x3c!(?:doctype|DOCTYPE)",end:"\x3e",name:"meta.tag.doctype.xml",captures:{0:{name:"meta.tag.doctype.xml"}},patterns:[{include:"#comment"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},tag:{begin:"\x3c/?[A-Za-z0-9]+",
end:"/?\x3e",captures:{0:{name:"meta.tag.xml"}},patterns:[{include:"#comment"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},xmlDeclaration:{begin:"\x3c\\?xml",end:"\\?\x3e",captures:{0:{name:"meta.tag.declaration.xml"}},patterns:[{include:"#comment"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}],name:"meta.tag.declaration.xml"}}});return{id:c[c.length-1].id,grammars:c,keywords:[]}});e("orion/editor/stylers/application_javascript/syntax",
["orion/editor/stylers/lib/syntax"],function(d){var c="class const debugger delete enum export extends function implements import in instanceof interface let new package private protected public static super typeof var void with".split(" "),a="break case catch continue default do else finally for if return switch throw try while yield".split(" "),b=["this"],f=["false","null","true","undefined"],h=[];h.push.apply(h,d.grammars);h.push({id:"orion.js",contentTypes:["application/javascript"],patterns:[{begin:"'(?:\\\\.|[^\\\\'])*\\\\$",
end:"^(?:$|(?:\\\\.|[^\\\\'])*('|[^\\\\]$))",name:"string.quoted.single.js"},{begin:'"(?:\\\\.|[^\\\\"])*\\\\$',end:'^(?:$|(?:\\\\.|[^\\\\"])*("|[^\\\\]$))',name:"string.quoted.double.js"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_singleLine"},{match:"/(?![\\s\\*])(?:\\\\.|[^/])+/(?:[gim]{0,3})",name:"string.regexp.js"},{include:"orion.lib#doc_block"},{include:"orion.c-like#comment_block"},{include:"#jsFunctionDef"},{include:"orion.lib#brace_open"},
{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.js"},{match:"\\b(?:"+a.join("|")+")\\b",name:"keyword.control.js"},{match:"\\b(?:"+f.join("|")+")\\b",name:"constant.language.js"},{match:"\\b(?:"+b.join("|")+
")\\b",name:"variable.language.js"}],repository:{jsFunctionDef:{begin:"(function)(\\s+[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*)?\\s*\\(",end:"\\)",captures:{1:{name:"keyword.operator.js"},2:{name:"entity.name.function.js"}},patterns:[{include:"orion.c-like#comment_singleLine"},{include:"orion.c-like#comment_block"},{match:"[^\\s,]+",name:"variable.parameter.js"}]}}});return{id:h[h.length-1].id,grammars:h,keywords:c.concat(a).concat(b).concat(f)}});e("orion/editor/stylers/text_css/syntax",
["orion/editor/stylers/lib/syntax"],function(d){var c="alignment-adjust alignment-baseline animation-delay animation-direction animation-duration animation-iteration-count animation-name animation-play-state animation-timing-function animation appearance azimuth backface-visibility background-attachment background-clip background-color background-image background-origin background-position background-repeat background-size background baseline-shift binding bleed bookmark-label bookmark-level bookmark-state bookmark-target border-bottom-color border-bottom-left-radius border-bottom-right-radius border-bottom-style border-bottom-width border-bottom border-collapse border-color border-image-outset border-image-repeat border-image-slice border-image-source border-image-width border-image border-left-color border-left-style border-left-width border-left border-radius border-right-color border-right-style border-right-width border-right border-spacing border-style border-top-color border-top-left-radius border-top-right-radius border-top-style border-top-width border-top border-width border bottom box-align box-decoration-break box-direction box-flex-group box-flex box-lines box-ordinal-group box-orient box-pack box-shadow box-sizing break-after break-before break-inside caption-side clear clip color-profile color column-count column-fill column-gap column-rule-color column-rule-style column-rule-width column-rule column-span column-width columns content counter-increment counter-reset crop cue-after cue-before cue cursor direction display dominant-baseline drop-initial-after-adjust drop-initial-after-align drop-initial-before-adjust drop-initial-before-align drop-initial-size drop-initial-value elevation empty-cells fit-position fit flex-align flex-flow flex-inline-pack flex-order flex-pack float-offset float font-family font-size-adjust font-size font-stretch font-style font-variant font-weight font grid-columns grid-rows hanging-punctuation height hyphenate-after hyphenate-before hyphenate-character hyphenate-lines hyphenate-resource hyphens icon image-orientation image-rendering image-resolution inline-box-align left letter-spacing line-height line-stacking-ruby line-stacking-shift line-stacking-strategy line-stacking list-style-image list-style-position list-style-type list-style margin-bottom margin-left margin-right margin-top margin mark-after mark-before mark marker-offset marks marquee-direction marquee-loop marquee-play-count marquee-speed marquee-style max-height max-width min-height min-width move-to nav-down nav-index nav-left nav-right nav-up opacity orphans outline-color outline-offset outline-style outline-width outline overflow-style overflow-x overflow-y overflow padding-bottom padding-left padding-right padding-top padding page-break-after page-break-before page-break-inside page-policy page pause-after pause-before pause perspective-origin perspective phonemes pitch-range pitch play-during position presentation-level punctuation-trim quotes rendering-intent resize rest-after rest-before rest richness right rotation-point rotation ruby-align ruby-overhang ruby-position ruby-span size speak-header speak-numeral speak-punctuation speak speech-rate stress string-set table-layout target-name target-new target-position target text-align-last text-align text-decoration text-emphasis text-height text-indent text-justify text-outline text-shadow text-transform text-wrap top transform-origin transform-style transform transition-delay transition-duration transition-property transition-timing-function transition unicode-bidi vertical-align visibility voice-balance voice-duration voice-family voice-pitch-range voice-pitch voice-rate voice-stress voice-volume volume white-space-collapse white-space widows width word-break word-spacing word-wrap z-index".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.css",contentTypes:["text/css"],patterns:[{begin:"'(?:\\\\.|[^\\\\'])*\\\\$",end:"^(?:$|(?:\\\\.|[^\\\\'])*('|[^\\\\]$))",name:"string.quoted.single.css"},{begin:'"(?:\\\\.|[^\\\\"])*\\\\$',end:'^(?:$|(?:\\\\.|[^\\\\"])*("|[^\\\\]$))',name:"string.quoted.double.css"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_block"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},
{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#number_decimal"},{include:"#number_hex"},{match:"(?i)\\b-?(?:\\.\\d+|\\d+\\.?\\d*)(?:%|em|ex|ch|rem|vw|vh|vmin|vmax|in|cm|mm|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?\\b",name:"constant.numeric.value.css"},{match:"(?:-webkit-|-moz-|-ms-|-o-|\\b)(?:"+c.join("|")+")\\b",name:"support.type.propertyName.css"}],repository:{number_hex:{match:"#[0-9A-Fa-f]+\\b",
name:"constant.numeric.hex.css"}}});return{id:a[a.length-1].id,grammars:a,keywords:c}});e("orion/editor/stylers/text_html/syntax",["orion/editor/stylers/application_javascript/syntax","orion/editor/stylers/text_css/syntax","orion/editor/stylers/application_xml/syntax"],function(d,c,a){var b=[];b.push.apply(b,d.grammars);b.push.apply(b,c.grammars);b.push.apply(b,a.grammars);b.push({id:"orion.html",contentTypes:["text/html"],patterns:[{begin:"(?i)(\x3cstyle)([^\x3e]*)(\x3e)",end:"(?i)(\x3c/style\x3e)",
captures:{1:{name:"meta.tag.html"},3:{name:"meta.tag.html"}},contentName:"source.css.embedded.html",patterns:[{include:"orion.css"}]},{begin:"(?i)\x3cscript\\s*\x3e|\x3cscript\\s.*?(?:language\\s*\x3d\\s*(['\"])javascript\\1|type\\s*\x3d\\s*(['\"])(?:text|application)/(?:javascript|ecmascript)\\2).*?\x3e",end:"(?i)\x3c/script\x3e",captures:{0:{name:"meta.tag.html"}},contentName:"source.js.embedded.html",patterns:[{include:"orion.js"}]},{begin:"\x3c/?[A-Za-z0-9]+",end:"/?\x3e",captures:{0:{name:"meta.tag.html"}},
patterns:[{include:"orion.xml#comment"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"#attribute"}]},{include:"orion.xml#comment"},{include:"orion.xml#doctype"},{include:"orion.xml#ampersandEscape"}],repository:{attribute:{match:"\\b(?:accept-charset|accept|accesskey|action|align|alt|async|autocomplete|autoplay|autosave|bgcolor|border|buffered|challenge|charset|checked|cite|class|codebase|code|color|colspan|cols|contenteditable|content|contextmenu|controls|coords|data-[A-Za-z_:][\\w.:-]*|data|datetime|default|defer|dirname|dir|disabled|download|draggable|dropzone|enctype|formaction|form|for|headers|height|hidden|high|hreflang|href|http-equiv|icon|id|ismap|itemprop|keytype|kind|label|language|lang|list|loop|low|manifest|maxlength|max|media|method|min|multiple|name|novalidate|open|optimum|pattern|ping|placeholder|poster|preload|pubdate|radiogroup|readonly|rel|required|reversed|rowspan|rows|sandbox|scoped|scope|seamless|selected|shape|sizes|size|span|spellcheck|srcdoc|srclang|srcset|src|start|step|style|summary|tabindex|target|title|type|usemap|value|width|wrap)\\b",
name:"meta.tag.attribute.html"}}});return{id:b[b.length-1].id,grammars:b,keywords:[]}});e("orion/editor/stylers/text_x-cshtml/syntax",["orion/editor/stylers/application_xml/syntax","orion/editor/stylers/text_html/syntax","orion/editor/stylers/text_x-csharp/syntax"],function(d,c,a){var b=[];b.push.apply(b,d.grammars);b.push.apply(b,c.grammars);b.push.apply(b,a.grammars);b.push({id:"orion.cshtml",contentTypes:["text/x-cshtml"],patterns:[{include:"#comment"},{include:"#codeBlock"},{include:"#expression"},
{include:"#reference"},{include:"orion.html"}],repository:{comment:{begin:{match:"@\\*",literal:"@*"},end:{match:"\\*@",literal:"*@"},name:"comment.block.cshtml"},codeBlock:{begin:"(^\\s*)(@)(?\x3d([^{]*){)",end:"}",captures:{2:{name:"entity.name.declaration.csharp"}},contentName:"source.csharp.embedded.cshtml",patterns:[{include:"orion.xml#tag"},{include:"#reference"},{include:"orion.csharp"}]},expression:{match:"^\\s*@[^{]*$",patterns:[{include:"#reference"},{include:"orion.csharp"}]},reference:{match:"@",
name:"entity.name.declaration.csharp"}}});return{id:b[b.length-1].id,grammars:b,keywords:[]}});e("plugins/languages/csharp/csharpPlugin",["orion/plugin","orion/editor/stylers/text_x-csharp/syntax","orion/editor/stylers/text_x-cshtml/syntax"],function(d,c,a){function b(b){b.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-csharp","extends":"text/plain",name:"C#",extension:["cs"]},{id:"text/x-cshtml","extends":"text/plain",name:"cshtml",extension:["cshtml"]}]});b.registerServiceProvider("orion.edit.highlighter",
{},c.grammars[c.grammars.length-1]);b.registerServiceProvider("orion.edit.highlighter",{},a.grammars[a.grammars.length-1])}return{connect:function(){var a=new d({name:"Orion C# Tool Support",version:"1.0",description:"This plugin provides C# tools support for Orion."});b(a);a.connect()},registerServiceProviders:b}});e("orion/editor/stylers/text_x-dockerfile/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="add cmd copy entrypoint env expose from maintainer onbuild run user volume workdir".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.dockerfile",contentTypes:["text/x-dockerfile"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"#numberSignComment"},{match:"\\b-?[0-9]+(\\.[0-9]+)?\\b",name:"constant.numeric.dockerfile"},{match:"(?i)^\\s*(?:"+c.join("|")+")\\b",name:"keyword.operator.dockerfile"}],repository:{numberSignComment:{begin:{match:"^\\s*#",literal:"#"},end:{match:"$",literal:""},name:"comment.line.number-sign.dockerfile",patterns:[{include:"orion.lib#todo_comment_singleLine"}]}}});
return{id:"orion.dockerfile",grammars:a,keywords:c}});e("plugins/languages/docker/dockerPlugin",["orion/plugin","orion/editor/stylers/text_x-dockerfile/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-dockerfile","extends":"text/plain",name:"dockerfile",extension:["dockerfile"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Editor Docker Tool Support",
version:"1.0",description:"This plugin provides Docker tools support for the Orion editor."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-erlang/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="xor when try rem receive query orelse or of not let if fun end div cond catch case bxor bsr bsl bor bnot begin band andalso and after".split(" "),a=[];a.push.apply(a,d.grammars);a.push({id:"orion.erlang",contentTypes:["text/x-erlang"],patterns:[{include:"#comment"},
{include:"#stringSingleLine"},{include:"#stringMultiLine"},{include:"#method"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.erlang"},{match:"^\\s*-(?:vsn|undef|type|spec|record|on_load|opaque|module|include_lib|include|import|ifndef|ifdef|file|export_type|export|endif|else|define|callback|compile|behaviour)\\b",
name:"keyword.operator.erlang"}],repository:{comment:{match:"%.*",name:"comment.line.erlang",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},method:{match:"(^|\\s)[a-zA-Z0-9_.]+(?\x3d\\(|\\s\\()",name:"entity.name.function.erlang"},stringMultiLine:{begin:'"(?:\\\\.|[^\\\\"])*$',end:'^(?:\\\\.|[^\\\\"])*"',name:"string.quoted.double.erlang"},stringSingleLine:{match:'"(?:\\\\.|[^\\\\"])*"',name:"string.quoted.double.erlang"}}});return{id:a[a.length-1].id,grammars:a,keywords:c}});e("plugins/languages/erlang/erlangPlugin",
["orion/plugin","orion/editor/stylers/text_x-erlang/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-erlang","extends":"text/plain",name:"Erlang",extension:["erl","hrl"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Erlang Tool Support",version:"1.0",description:"This plugin provides Erlang tools support for Orion."});a(b);b.connect()},
registerServiceProviders:a}});e("orion/form",[],function(){function d(c){return encodeURIComponent(c).replace(/[!'()*]/g,escape).replace("%20","+")}return{encodeFormData:function(c){c=c||{};for(var a=Object.keys(c),b=[],f=0;f<a.length;f++){var h=a[f],e=c[h];b.push(d(h)+"\x3d"+d(e))}return b.join("\x26")},encodeSlug:function(c){return c.replace(/([^\u0020-\u007e]|%)+/g,encodeURIComponent)}}});e("orion/editor/stylers/text_x-go/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="break case const continue default defer else fallthrough false for func goto go if import nil package range return select switch true type var".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.go",contentTypes:["text/x-go"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{begin:"`",end:"`",name:"string.quoted.raw.go"},{include:"orion.c-like#comment_singleLine"},{include:"orion.c-like#comment_block"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},
{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.go"},{match:"\\b(?:len|cap|new|make|append|close|copy|delete|complex|real|imag|panic|recover)\\b",name:"support.function.go"},{match:"\\b(?:bool|chan|uint8|uint16|uint32|uint64|int8|int16|int32|int64|float32|float64|complex64|complex128|byte|map|rune|uint|interface|int|uintptr|string|struct|error)\\b",name:"support.function.type"}]});return{id:a[a.length-
1].id,grammars:a,keywords:c}});e("plugins/languages/go/goPlugin",["orion/plugin","orion/form","orion/editor/stylers/text_x-go/syntax"],function(d,c,a){function b(b){b.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-go","extends":"text/plain",name:"Go",extension:["go"]}]});b.registerServiceProvider("orion.edit.highlighter",{},a.grammars[a.grammars.length-1]);b.registerServiceProvider("orion.edit.contentAssist",{computeProposals:function(a,b,c){var d=c.delimiter,f=c.indentation,
e=c.tab,q=["inner","if","if","if ${cond} {"+d+f+e+"${cursor}"+d+f+"}","outer","func","func","func ${name}() (${retval} ${type}) {"+d+f+e+"${cursor}"+d+f+"}","inner","for","for","for ${cond} {"+d+f+e+"${cursor}"+d+f+"}","inner","switch","switch","switch {"+d+f+"case ${cond}:"+d+f+e+"${cursor}"+d+f+"default:"+d+f+"}","inner","select","select","select {"+d+f+"case ${cond}:"+d+f+e+"${cursor}"+d+f+"default:"+d+f+"}","outer","var","var","var ("+d+f+e+"${cursor}"+d+f+"}","outer","const","const","const ("+
d+f+e+"${cursor}"+d+f+"}","outer","import","import","import ("+d+f+e+"${cursor}"+d+f+"}","outer","","method","func (this *${type}) ${name}() (${retval} ${type}) {"+d+f+e+"${cursor}"+d+f+"}","outer","","struct","type ${name} struct {"+d+f+e+"${cursor}"+d+f+"}","outer","","interface","type ${name} interface {"+d+f+e+"${cursor}"+d+f+"}","inner","","make channel","ch :\x3d make(chan ${type}, 0)","inner","","make array","arr :\x3d make([]${type}, 1, 1)","outer","","main","func main() {"+d+f+e+"${cursor}"+
d+f+"}"],g=[];0===a.length&&0===b&&(g.push({description:"new file template",proposal:"// COPYRIGHT"+d+""+d+"// GODOC"+d+"package ${name}"+d+d+"import ("+d+e+"${import}"+d+")"+d+d+"func main() {"+d+e+d+"}"+d,escapePosition:68+10*d.length,positions:[{offset:28+3*d.length,length:7},{offset:43+7*d.length,length:9}]}),g.push({description:"new test template",proposal:"// COPYRIGHT"+d+""+d+"package main"+d+d+"import ("+d+e+"testing"+d+")"+d+d+"func Test1(t *testing.T) {"+d+e+d+"}"+d,escapePosition:68+9*
d.length,positions:[]}));for(a=0;a<q.length;a+=4){var e=q[a],m=q[a+2],d=q[a+3];if(0===q[a+1].indexOf(c.prefix)&&!("inner"===e&&""===f)&&!("outer"===e&&""!==f)){0===d.indexOf(c.prefix)&&(d=d.substring(c.prefix.length));e={description:m,positions:[]};m=d.indexOf("${cursor}");-1!==m&&(e.escapePosition=m+b,d=d.replace("${cursor}",""));e.proposal=d;for(m=0;-1!==m&&m<d.length-4;)if(m=d.indexOf("${",m+1),-1!==m){var l=m+b,r=d.indexOf("}",m+1)+1-m;0<r&&e.positions.push({offset:l,length:r})}g.push(e)}}return g}},
{name:"Go content assist",contentType:["text/x-go"]})}return{connect:function(){var a=new d({name:"Orion Go Language Tool Support",version:"1.0",description:"This plugin provides Go language tools support for Orion."});b(a);a.connect()},registerServiceProviders:b}});e("orion/editor/stylers/text_x-ruby/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="alias_method alias attr_accessor attr_reader attr_writer attr BEGIN class defined? def END extend gem include initialize in load lambda module_function module new not public prepend private protected require_relative require undef __ENCODING__ __END__ __FILE__ __LINE__".split(" "),
a="and begin break case catch do else elsif end ensure fail for if loop next or raise redo rescue retry return then throw unless until when while yield".split(" "),b=["false","nil","true"],f=["self","super"],h=[];h.push.apply(h,d.grammars);h.push({id:"orion.ruby",contentTypes:["text/x-ruby"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"#symbol_quoted_single"},{include:"#symbol_quoted_double"},{include:"#symbol"},{include:"#classRef"},{match:"/(?![\\s])(?:\\\\.|[^/])+/(?:[ioxmuesn]\\b)?",
name:"string.regexp.ruby"},{match:{match:"#.*",literal:"#"},name:"comment.line.number-sign.ruby",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},{begin:{match:"^\x3dbegin\\b",literal:"\x3dbegin"},end:{match:"^\x3dend\\b",literal:"\x3dend"},name:"comment.block.ruby",patterns:[{match:"(\\b)(TODO)(\\b)(((?!\\*/).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.block"}}}]},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},
{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{include:"#variable"},{match:"\\b0[bB][01]+\\b",name:"constant.numeric.binary.ruby"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.ruby"},{match:"\\b(?:"+a.join("|")+")\\b",name:"keyword.control.ruby"},{match:"\\b(?:"+b.join("|")+")\\b",name:"constant.language.ruby"},
{match:"\\b(?:"+f.join("|")+")\\b",name:"variable.language.ruby"}],repository:{classRef:{match:"\\w+::\\w+"},symbol:{match:":\\w+",name:"entity.name.symbol.ruby"},symbol_quoted_single:{match:":'[^']*'",name:"entity.name.symbol.quoted.single.ruby"},symbol_quoted_double:{match:':"[^"]*"',name:"entity.name.symbol.quoted.double.ruby"},variable:{match:"@\\w+",name:"entity.name.variable.ruby"}}});return{id:h[h.length-1].id,grammars:h,keywords:c.concat(a).concat(b).concat(f)}});e("orion/editor/stylers/text_x-haml/syntax",
["orion/editor/stylers/lib/syntax","orion/editor/stylers/text_x-ruby/syntax"],function(d,c){var a=[];a.push.apply(a,d.grammars);a.push.apply(a,c.grammars);a.push({id:"orion.haml",contentTypes:["text/x-haml"],patterns:[{include:"#inlineRuby"},{include:"#interpolatedRuby"},{include:"#tagWithRubySymbols"},{include:"#tagWithHTMLAttributes"},{include:"#doctype"},{include:"#tag"},{include:"#htmlComment"},{include:"#hamlComment"}],repository:{doctype:{match:"^!!!.*$",name:"meta.tag.doctype.haml"},hamlComment:{match:{match:"\\-#.*$",
literal:"-#"},name:"comment.line.haml",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},htmlComment:{match:"/[^[].*$",name:"comment.line.html.haml"},inlineRuby:{begin:"(?:^|[^\\\\])(?:\x3d|-|~|\x26\x3d\x3d?|!\x3d\x3d?)",end:"(?:^|[^,])$",patterns:[{include:"orion.ruby"}]},interpolatedRuby:{begin:"#{",end:"}",patterns:[{include:"orion.ruby"}]},tag:{match:"^\\s*%[^\\b]+?\\b",name:"meta.tag.haml"},tagWithHTMLAttributes:{begin:"(^\\s*)(%[^\\s(]+?)\\(",end:"\\)\\s*$",beginCaptures:{2:{name:"meta.tag.haml"}},
patterns:[{match:"[^\\s\x3d]+(?\x3d\x3d)",name:"entity.name.attribute.html.haml"},{include:"orion.ruby#variable"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},tagWithRubySymbols:{begin:"(^\\s*)(%[^\\b]+?)\\b{",end:"}\\s*$",beginCaptures:{2:{name:"meta.tag.haml"}},patterns:[{include:"orion.ruby#symbol"},{include:"orion.ruby#variable"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]}}});return{id:a[a.length-1].id,grammars:a,keywords:[]}});
e("plugins/languages/haml/hamlPlugin",["orion/plugin","orion/editor/stylers/text_x-haml/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-haml","extends":"text/plain",name:"Haml",extension:["haml"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Haml Tool Support",version:"1.0",description:"This plugin provides Haml tools support for Orion."});
a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-jade/syntax",["orion/editor/stylers/lib/syntax","orion/editor/stylers/application_javascript/syntax"],function(d,c){var a=[];a.push.apply(a,d.grammars);a.push.apply(a,c.grammars);a.push({id:"orion.jade",contentTypes:["text/x-jade"],patterns:[{include:"#comment_singleLine"},{include:"#code"},{include:"#control"},{include:"#caseBranch"},{include:"#mixinWithParameters"},{include:"#mixinRefWithArguments"},{include:"#tagWithAttributes"},
{include:"#interpolatedJS"},{include:"#interpolatedTag"},{include:"#mixin"},{include:"#mixinRef"},{include:"#doctype"},{include:"#filter"},{include:"#case"},{include:"#andAttributes"},{include:"#otherKeywords"},{include:"#tag"}],repository:{andAttributes:{match:"\x26attributes\\b",name:"keyword.operator.jade"},"case":{match:"(^\\s*)(case)\\b",captures:{2:{name:"keyword.control.jade"}}},caseBranch:{begin:"(^\\s*)(when|default)\\s*",end:":|$",patterns:[{include:"orion.js"}],beginCaptures:{2:{name:"keyword.control.jade"}}},
code:{match:"(^\\s*- |\x3d |!\x3d ).*$",patterns:[{include:"orion.js"}]},comment_singleLine:{match:{match:"^\\s*//.*",literal:"//"},name:"comment.line.double-slash.jade",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},control:{begin:"(^\\s*)(if|else( if)?|each|for|unless|while)\\b",end:"$",beginCaptures:{2:{name:"keyword.control.jade"}},patterns:[{include:"orion.js"}]},doctype:{match:"(^\\s*)(doctype.+$)",captures:{2:{name:"meta.tag.doctype.jade"}}},filter:{match:"(^\\s*)(:\\w+)",captures:{2:{name:"entity.other.filter.jade"}}},
interpolatedJS:{begin:"(#{)",end:"(})",captures:{1:{name:"string.interpolated.js.jade"}},patterns:[{include:"orion.js"}]},interpolatedTag:{begin:"(#\\[)",end:"(\\])",captures:{1:{name:"string.interpolated.tag.jade"}},patterns:[{begin:"(\\.|\\w+)\\s*\\(",end:"(\\))(/)?",beginCaptures:{1:{name:"meta.tag.jade"}},endCaptures:{2:{name:"meta.tag.jade"}},patterns:[{include:"orion.js"}]}]},mixin:{match:"(^\\s*)(mixin)(\\s+)(\\w+)",captures:{2:{name:"keyword.operator.jade"},4:{name:"entity.name.mixin.jade"}}},
mixinRef:{match:"(^\\s*)(\\+\\w+)",captures:{2:{name:"entity.name.mixin.jade"}}},mixinRefWithArguments:{begin:"(^\\s*)(\\+\\w+)\\s*\\(",end:"\\)|$",captures:{2:{name:"entity.name.mixin.jade"}},patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.lib#number_decimal"}]},mixinWithParameters:{begin:"(^\\s*)(mixin)(\\s+)(\\w+)\\s*\\(",end:"\\)|$",beginCaptures:{2:{name:"keyword.operator.jade"},4:{name:"entity.name.mixin.jade"}},patterns:[{match:"[^\\s,]+",
name:"variable.parameter.jade"}]},otherKeywords:{match:"(^\\s*)(block|extends|include)\\b",captures:{2:{name:"keyword.operator.jade"}}},tag:{match:"(^\\s*)(\\w+|(?\x3d\\.)|(?\x3d#))(#\\w*|\\.\\w*)*(/?)",captures:{2:{name:"meta.tag.jade"},4:{name:"meta.tag.jade"}}},tagWithAttributes:{begin:"(^\\s*)(\\w+|(?\x3d\\.)|(?\x3d#))(#\\w*|\\.\\w*)*\\s*\\(",end:"(\\))(/)?",beginCaptures:{2:{name:"meta.tag.jade"}},endCaptures:{2:{name:"meta.tag.jade"}},patterns:[{include:"orion.js"}]}}});return{id:a[a.length-
1].id,grammars:a,keywords:"\x26attributes block case default doctype each else extends for if include mixin unless when while".split(" ")}});e("plugins/languages/jade/jadePlugin",["orion/plugin","orion/editor/stylers/text_x-jade/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-jade","extends":"text/plain",name:"Jade",extension:["jade"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=
new d({name:"Orion Jade Tool Support",version:"1.0",description:"This plugin provides Jade tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-java-source/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="abstract boolean byte char class double extends final float implements import instanceof int interface long native new package private protected public short static synchronized throws transient void volatile".split(" "),a="break case catch continue default do else finally for if return switch throw try while".split(" "),
b=["false","null","true"],f=["this","super"],h=[];h.push.apply(h,d.grammars);h.push({id:"orion.java",contentTypes:["text/x-java-source"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_singleLine"},{include:"orion.lib#doc_block"},{include:"orion.c-like#comment_block"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},
{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.java"},{match:"\\b(?:"+a.join("|")+")\\b",name:"keyword.control.java"},{match:"\\b(?:"+b.join("|")+")\\b",name:"constant.language.java"},{match:"\\b(?:"+f.join("|")+")\\b",name:"variable.language.java"}]});return{id:h[h.length-1].id,grammars:h,keywords:c.concat(a).concat(b).concat(f)}});e("orion/editor/stylers/application_x-jsp/syntax",
["orion/editor/stylers/lib/syntax","orion/editor/stylers/text_x-java-source/syntax","orion/editor/stylers/text_html/syntax"],function(d,c,a){var b=[];b.push.apply(b,d.grammars);b.push.apply(b,c.grammars);b.push.apply(b,a.grammars);b.push({id:"orion.jsp",contentTypes:["application/x-jsp"],patterns:[{include:"orion.html"},{include:"#jspComment"},{include:"#jspJavaFragment"},{include:"#jspDirectiveInclude"},{include:"#jspDirectivePage"},{include:"#jspDirectiveTaglib"}],repository:{jspComment:{begin:{match:"\x3c%--",
literal:"\x3c%--"},end:{match:"--%\x3e",literal:"\x3c%--"},name:"comment.block.jsp",patterns:[{match:"(\\b)(TODO)(\\b)(((?!--%\x3e).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.line"}}}]},jspDirectiveInclude:{begin:"\x3c%@\\s+include(?:\\s|$)",end:"%\x3e",captures:{0:{name:"entity.name.directive.include.jsp"}},patterns:[{match:"\\bfile\\b",name:"entity.other.attribute-name.jsp"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},
jspDirectivePage:{begin:"\x3c%@\\s+page(?:\\s|$)",end:"%\x3e",captures:{0:{name:"entity.name.directive.page.jsp"}},patterns:[{match:"\\b(?:autoFlush|buffer|contentType|errorPage|extends|import|info|isErrorPage|isThreadSafe|language|pageEncoding|session)\\b",name:"entity.other.attribute-name.jsp"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},jspDirectiveTaglib:{begin:"\x3c%@\\s+taglib(?:\\s|$)",end:"%\x3e",captures:{0:{name:"entity.name.directive.taglib.jsp"}},
patterns:[{match:"\\b(?:uri|prefix)\\b",name:"entity.other.attribute-name.jsp"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"}]},jspJavaFragment:{begin:"\x3c%(?:\x3d|!)?(?:\\s|$)",end:"%\x3e",captures:{0:{name:"entity.name.declaration.java"}},contentName:"source.java.embedded.jsp",patterns:[{include:"orion.java"}]}}});return{id:b[b.length-1].id,grammars:b,keywords:[]}});e("plugins/languages/java/javaPlugin",["orion/plugin","orion/editor/stylers/text_x-java-source/syntax",
"orion/editor/stylers/application_x-jsp/syntax"],function(d,c,a){function b(b){b.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-java-source","extends":"text/plain",name:"Java",extension:["java"]},{id:"application/x-jsp","extends":"text/plain",name:"Java Server Page",extension:["jsp"]}]});b.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1]);b.registerServiceProvider("orion.edit.highlighter",{},a.grammars[a.grammars.length-1])}return{connect:function(){var a=
new d({name:"Orion Java Tool Support",version:"1.0",description:"This plugin provides Java tools support for Orion."});b(a);a.connect()},registerServiceProviders:b}});e("plugins/languages/launch/launchPlugin",["orion/plugin"],function(d){function c(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-launch","extends":"application/json",name:"Launch file",extension:["launch"]}]})}return{connect:function(){var a=new d({name:"Orion Launch File Tool Support",version:"1.0",
description:"This plugin provides tools support for Orion Launch files."});c(a);a.connect()},registerServiceProviders:c}});e("orion/editor/stylers/text_x-lua/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="and break do else elseif end false for function if in local nil not or repeat return then true until while".split(" "),a=[];a.push.apply(a,d.grammars);a.push({id:"orion.lua",contentTypes:["text/x-luasrc","text/x-lua"],patterns:[{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},
{include:"orion.c-like#comment_singleLine"},{include:"#comment_block_dash_dash"},{include:"#comment_singleLine_dash_dash"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{include:"#base_functions"},{include:"#base_variables"},{include:"#reserved_underscore_capital"},
{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.lua"}],repository:{comment_block_dash_dash:{begin:{match:"--\\[\\[",literal:"--[["},end:{match:"\\]\\]",literal:"]]"},name:"comment.block.dash-dash.lua",patterns:[{match:"(\\b)(TODO)(\\b)(((?!\\]\\]).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.block"}}}]},comment_singleLine_dash_dash:{begin:{match:"--",literal:"--"},end:{match:"$",literal:""},name:"comment.line.dash-dash.lua",
patterns:[{include:"orion.lib#todo_comment_singleLine"}]},base_functions:{match:"\\b(?:assert|arg|collectgarbage|dofile|error|getfenv|getmetatable|ipairs|load|loadfile|loadstring|next|pairs|pcall|print|rawequal|rawget|rawset|require|select|setfenv|setmetatable|tonumber|tostring|type|unpack|xpcall)\\b",name:"support.function.lua"},base_variables:{match:"\\b(?:_G|LUA_INIT|LUA_PATH|LUA_CPATH|_VERSION)\\b",name:"support.variable.lua"},reserved_underscore_capital:{match:"\\b_[A-Z]*\\b",name:"constant.other.userdefined.lua"}}});
return{id:a[a.length-1].id,grammars:a,keywords:c}});e("plugins/languages/lua/luaPlugin",["orion/plugin","orion/editor/stylers/text_x-lua/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-lua","extends":"text/plain",name:"Lua",extension:["lua"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Lua Tool Support",version:"1.0",description:"This plugin provides Lua tools support for Orion."});
a(b);b.connect()},registerServiceProviders:a}});e("orion/i18nUtil",[],function(){return{formatMessage:function(d){var c=/\$\{([^\}]+)\}/g,a=arguments;return 2===a.length&&a[1]&&"object"===typeof a[1]?d.replace(c,function(b,c){return a[1][c]}):d.replace(c,function(b,c){return a[(c<<0)+1]})}}});(function(){function d(a,b,c,d,e,p){b[a]&&(c.push(a),(!0===b[a]||1===b[a])&&d.push(e+a+"/"+p))}function c(a,b,c,d,e){b=d+b+"/"+e;x._fileExists(a.toUrl(b+".js"))&&c.push(b)}function a(b,c,d){for(var e in c)c.hasOwnProperty(e)&&
(!b.hasOwnProperty(e)||d)?b[e]=c[e]:"object"===typeof c[e]&&(!b[e]&&c[e]&&(b[e]={}),a(b[e],c[e],d))}var b=/(^.*(^|\/)nls(\/|$))([^\/]*)\/?([^\/]*)/;e("i18n",["module"],function(f){var e=f.config?f.config():{};return{version:"2.0.4",load:function(f,w,n,p){p=p||{};p.locale&&(e.locale=p.locale);var k=b.exec(f),q=k[1],g=k[4],m=k[5],l=g.split("-"),r=[],x={},u,v="";k[5]?(q=k[1],f=q+m):(m=k[4],g=e.locale,g||(g=e.locale="undefined"===typeof navigator?"root":(navigator.language||navigator.userLanguage||"root").toLowerCase()),
l=g.split("-"));if(p.isBuild){r.push(f);c(w,"root",r,q,m);for(u=0;u<l.length;u++)g=l[u],v+=(v?"-":"")+g,c(w,v,r,q,m);if(p.locales)for(k=0;k<p.locales.length;k++){g=p.locales[k];l=g.split("-");v="";for(f=0;f<l.length;f++)g=l[f],v+=(v?"-":"")+g,c(w,v,r,q,m)}w(r,function(){n()})}else w([f],function(b){var c=[],f;d("root",b,c,r,q,m);for(u=0;u<l.length;u++)f=l[u],v+=(v?"-":"")+f,d(v,b,c,r,q,m);w(r,function(){var d,f,e;for(d=c.length-1;-1<d&&c[d];d--){e=c[d];f=b[e];if(!0===f||1===f)f=w(q+e+"/"+m);a(x,f)}n(x)})})}}})})();
e("orion/nls/messages",{root:!0});e("orion/nls/root/messages",{Navigator:"Navigator",Sites:"Sites",Shell:"Shell",ShellLinkWorkspace:"Shell","Get Plugins":"Get Plugins",Global:"Global",Editor:"Editor",EditorRelatedLink:"Show Current Folder",EditorRelatedLinkParent:"Show Enclosing Folder",EditorLinkWorkspace:"Edit",EditorRelatedLinkProj:"Show Project","Filter bindings":"Filter bindings",orionClientLabel:"Orion client repository","Orion Editor":"Orion Editor","Orion Image Viewer":"Orion Image Viewer",
"Orion Markdown Editor":"Orion Markdown Editor","Orion Markdown Viewer":"Orion Markdown Viewer","Orion JSON Editor":"Orion JSON Editor","View on Site":"View on Site","View this file or folder on a web site hosted by Orion":"View this file or folder on a web site hosted by Orion.",ShowAllKeyBindings:"Show a list of all the keybindings on this page","Show Keys":"Show Keys",HideShowBannerFooter:"Hide or show the page banner","Toggle banner and footer":"Toggle banner",ChooseFileOpenEditor:"Choose a file by name and open an editor on it",
FindFile:"Find File Named...","System Configuration Details":"System Configuration Details","System Config Tooltip":"Go to the System Configuration Details page","Background Operations":"Background Operations","Background Operations Tooltip":"Go to the Background Operations page","Operation status is unknown":"Operation status is unknown","Unknown item":"Unknown item",NoSearchAvailableErr:"Can't search: no search service is available",Related:"Related",Options:"Options","LOG: ":"LOG: ",View:"View",
"no parent":"no parent","no tree model":"no tree model","no renderer":"no renderer","could not find table row ":"could not find table row ",Operations:"Operations","Operations running":"Operations running",SomeOpWarning:"Some operations finished with warning",SomeOpErr:"Some operations finished with error","no service registry":"no service registry",Tasks:"Tasks",Close:"Close","Expand all":"Expand all","Collapse all":"Collapse all",Search:"Search","Advanced search":"Advanced search",Submit:"Submit",
More:"More","Recent searches":"Recent searches","Regular expression":"Regular expression","Search options":"Search options","Global search":"Global search","Orion Home":"Orion Home","Close notification":"Close notification",OpPressSpaceMsg:"Operations - Press spacebar to show current operations","Toggle side panel":"Toggle side panel","Open or close the side panel":"Open or close the side panel",Projects:"Projects","Toggle Sidebar":"Toggle Sidebar","Sample HTML5 Site":"Sample HTML5 Site","Generate an HTML5 'Hello World' website, including JavaScript, HTML, and CSS files.":"Generate an HTML5 'Hello World' website, including JavaScript, HTML, and CSS files.",
"Sample Orion Plugin":"Sample Orion Plugin","Generate a sample plugin for integrating with Orion.":"Generate a sample plugin for integrating with Orion.",Browser:"Web Browser",OutlineProgress:"Getting outline for ${0} from ${1}",outlineTimeout:"Outline service timed out. Try reloading the page and opening the outline again.",UnknownError:"An unknown error occurred.",Filter:"Filter (* \x3d any string, ? \x3d any character)",TemplateExplorerLabel:"Templates",OpenTemplateExplorer:"Open Template Explorer",
Edit:"Edit",CentralNavTooltip:"Toggle Navigation Menu","Wrote: ${0}":"Wrote: ${0}",GenerateHTML:"Generate HTML file",GenerateHTMLTooltip:"Write an HTML file generated from the current Markdown editor content","alt text":"alt text",blockquote:"blockquote",code:"code","code (block)":"code (block)","code (span)":"code (span)",emphasis:"emphasis","fenced code (${0})":"fenced code (${0})","header (${0})":"header (${0})","horizontal rule":"horizontal rule",label:"label","link (auto)":"link (auto)","link (image)":"link (image)",
"link (inline)":"link (inline)","link label":"link label","link label (optional)":"link label (optional)","link (ref)":"link (ref)","list item (bullet)":"list item (bullet)","list item (numbered)":"list item (numbered)","strikethrough (${0})":"strikethrough (${0})",strong:"strong","table (${0})":"table (${0})",text:"text","title (optional)":"title (optional)",url:"url",TogglePaneOrientationTooltip:"Toggle split pane orientation",WarningDuplicateLinkId:"Duplicate link ID: ${0} (link IDs are not case-sensitive)",
WarningHeaderTooDeep:"Header level cannot exceed 6",WarningLinkHasNoText:"Link has no text",WarningLinkHasNoURL:"Link has no URL",WarningOrderedListItem:"Ordered list item within unordered list",WarningOrderedListShouldStartAt1:"The first item in an ordered list should have index 1",WarningUndefinedLinkId:"Undefined link ID: ${0}",WarningUnorderedListItem:"Unordered list item within ordered list",PageTitleFormat:"${0} - ${1}",KeyCTRL:"Ctrl",KeySHIFT:"Shift",KeyALT:"Alt",KeyBKSPC:"Backspace",KeyDEL:"Del",
KeyEND:"End",KeyENTER:"Enter",KeyESCAPE:"Esc",KeyHOME:"Home",KeyINSERT:"Ins",KeyPAGEDOWN:"Page Down",KeyPAGEUP:"Page Up",KeySPACE:"Space",KeyTAB:"Tab","a year":"a year",years:"${0} years","a month":"a month",months:"${0} months","a day":"a day",days:"${0} days","an hour":"an hour",hours:"${0} hours","a minute":"a minute",minutes:"${0} minutes",timeAgo:"${0} ago",justNow:"just now"});e("plugins/languages/markdown/markdownPlugin",["orion/plugin","orion/i18nUtil","i18n!orion/nls/messages"],function(d,
c,a){function b(b){b.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-markdown","extends":"text/plain",name:"Markdown",extension:["md"]}]});b.registerServiceProvider("orion.edit.contentAssist",{computeProposals:function(b,d,f){b=f.selection.start!==f.selection.end?b.substring(f.selection.start,f.selection.end):null;var e=f.delimiter,p=b&&-1!==b.indexOf(e),k=/^[ ]{0,3}$/.test(f.line),q=[];q.push({description:a.emphasis,escapePosition:b?null:d+1,proposal:"*"+(b?b:"")+"*"});
q.push({description:a.strong,escapePosition:b?null:d+2,proposal:"**"+(b?b:"")+"**"});if(!p){var g=k&&!b?a.text:"";q.push({description:c.formatMessage(a["header (${0})"],"atx"),positions:k?[{offset:d+1,length:g.length}]:null,proposal:(k?"":e)+"#"+g+(b?b:"")})}p||q.push({description:a["link (auto)"],escapePosition:b?null:d+1,proposal:"\x3c"+(b?b:"")+"\x3e"});var g=b||a.text,m=a.url,l=a["title (optional)"];q.push({description:a["link (inline)"],positions:[{offset:d+1,length:g.length},{offset:d+3+g.length,
length:m.length},{offset:d+5+g.length+m.length,length:l.length}],proposal:"["+g+"]("+m+' "'+l+'")'});g=b||a["alt text"];m=a.url;l=a["title (optional)"];q.push({description:a["link (image)"],positions:[{offset:d+2,length:g.length},{offset:d+4+g.length,length:m.length},{offset:d+6+g.length+m.length,length:l.length}],proposal:"!["+g+"]("+m+' "'+l+'")'});g=b||a.text;m=a["link label (optional)"];q.push({description:a["link (ref)"],positions:[{offset:d+1,length:g.length},{offset:d+3+g.length,length:m.length}],
proposal:"["+g+"]["+m+"]"});if(!p){var g=b||a.label,m=a.url,l=a["title (optional)"],r=k?"":e;q.push({description:a["link label"],positions:[{offset:d+r.length+1,length:g.length},{offset:d+r.length+4+g.length,length:m.length},{offset:d+r.length+5+g.length+m.length,length:l.length}],proposal:r+"["+g+"]: "+m+" "+l+e})}p||(g=k&&!b?a.code:"",f=k?"    ".substring(0,4-f.indentation.length):e+e+"    ",q.push({description:a["code (block)"],positions:g?[{offset:d+f.length,length:g.length}]:null,proposal:f+
g+(b?b:"")}));q.push({description:a["code (span)"],escapePosition:b?null:d+1,proposal:"`"+(b?b:"")+"`"});q.push({description:a["horizontal rule"],proposal:(k?"":e)+"- - -"+e+(b?b:"")});p||(f=k&&!b?a.text:"",q.push({description:a.blockquote,positions:k?[{offset:d+2,length:f.length}]:null,proposal:(k?"":e)+"\x3e "+f+(b?b:"")}));f=k&&!b?a.text:"";q.push({description:a["list item (numbered)"],positions:k?[{offset:d+3,length:f.length}]:null,proposal:(k?"":e)+"1. "+f+(b?b:"")});q.push({description:a["list item (bullet)"],
positions:k?[{offset:d+2,length:f.length}]:null,proposal:(k?"":e)+"* "+f+(b?b:"")});q.push({style:"hr"});q.push({description:c.formatMessage(a["strikethrough (${0})"],"gfm"),escapePosition:b?null:d+2,proposal:"~~"+(b?b:"")+"~~"});k=k?"":e;q.push({description:c.formatMessage(a["table (${0})"],"gfm"),positions:[{offset:d+k.length,length:5},{offset:d+k.length+7,length:9},{offset:d+k.length+16+e.length,length:6},{offset:d+k.length+23+e.length,length:9},{offset:d+k.length+32+2*e.length,length:4},{offset:d+
k.length+39+2*e.length,length:4}],proposal:k+"hLeft |hCentered"+e+":-----|:-------:"+e+"item  |item     "+e+(b?b:"")});q.push({description:c.formatMessage(a["fenced code (${0})"],"gfm"),escapePosition:b?null:d+3,proposal:"```"+(b?b:"")+"```"});return q}},{name:"Markdown content assist",contentType:["text/x-markdown"]})}return{connect:function(){var a=new d({name:"Orion Extended Markdown Language Tool Support",version:"1.0",description:"This plugin provides extended Markdown language tools support for Orion."});
b(a);a.connect()},registerServiceProviders:b}});e("orion/editor/stylers/text_x-objective-c/syntax",["orion/editor/stylers/text_x-csrc/syntax"],function(d){var c="atomic BOOL bycopy byref Class id IMP inout in nil nonatomic NO NULL oneway out Protocol retain SEL self super YES".split(" "),a="@catch @class @dynamic @end @finally @implementation @interface @private @property @protected @protocol @public @selector @synthesize @throw @try".split(" "),b=["import"],f=[];f.push.apply(f,d.grammars);f.push({id:"orion.objectiveC",
contentTypes:["text/x-objective-c"],patterns:[{include:"#objectiveCString"},{include:"orion.c"},{include:"#objectiveCDirective"},{include:"#objectiveCKeyword"}],repository:{objectiveCDirective:{match:"#\\s*(?:"+b.join("|")+")\\b[^$]*",name:"meta.preprocessor.objective-c"},objectiveCKeyword:{match:"(\\b(?:"+c.join("|")+")|(?:"+a.join("|")+"))\\b",name:"keyword.operator.objective-c"},objectiveCString:{match:'@"(?:\\\\.|[^"])*"?',name:"string.quoted.double.objective-c"}}});return{id:f[f.length-1].id,
grammars:f,keywords:d.keywords.concat(c).concat(b).concat(a)}});e("plugins/languages/objectiveC/objectiveCPlugin",["orion/plugin","orion/editor/stylers/text_x-objective-c/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-objective-c","extends":"text/plain",name:"Objective-C",extension:["m","mm","h"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Objective-C Tool Support",
version:"1.0",description:"This plugin provides Objective-C tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-php/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="abstract and array as callable class clone const declare echo empty eval extends final function global implements include include_once insteadof interface instanceof isset list namespace new or parent print private protected public require require_once static trait unset use var xor __halt_compiler __CLASS__ __DIR__ __FILE__ __FUNCTION__ __LINE__ __METHOD__ __NAMESPACE__ __TRAIT__".split(" "),
a="break case catch continue default die do else elseif enddeclare endfor endforeach endif endswitch endwhile exit finally for foreach goto if return switch throw try while yield".split(" "),b="false FALSE null NULL true TRUE".split(" "),f=["self"],e=[];e.push.apply(e,d.grammars);e.push({id:"orion.php",contentTypes:["text/x-php"],patterns:[{begin:"(?i)\x3c(\\?|%(?!php))(?:\x3d|php)?(?:\\s|$)",end:"[\\1]\x3e",captures:{0:{name:"entity.name.declaration.php"}},contentName:"source.php.embedded",patterns:[{include:"orion.lib#string_doubleQuote"},
{include:"orion.lib#string_singleQuote"},{include:"orion.c-like#comment_singleLine"},{include:"orion.lib#doc_block"},{include:"orion.c-like#comment_block"},{match:{match:"#.*",literal:"#"},name:"comment.line.number-sign.php",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},{begin:"\x3c\x3c\x3c(\\w+)$",end:"^\\1;$",name:"string.unquoted.heredoc.php"},{begin:"\x3c\x3c\x3c'(\\w+)'$",end:"^\\1;$",name:"string.unquoted.heredoc.nowdoc.php"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},
{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{match:"\\b0[bB][01]+\\b",name:"constant.numeric.binary.php"},{include:"orion.lib#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.php"},{match:"\\b(?:"+a.join("|")+")\\b",name:"keyword.control.php"},{match:"\\b(?:"+b.join("|")+")\\b",name:"constant.language.php"},
{match:"\\b(?:"+f.join("|")+")\\b",name:"variable.language.php"}]},{include:"orion.html"}]});return{id:e[e.length-1].id,grammars:e,keywords:c.concat(a).concat(b).concat(f)}});e("plugins/languages/php/phpPlugin",["orion/plugin","orion/editor/stylers/text_x-php/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-php","extends":"text/plain",name:"PHP",extension:"php php3 php4 php5 phpt phtml aw ctp".split(" ")}]});a.registerServiceProvider("orion.edit.highlighter",
{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion PHP Tool Support",version:"1.0",description:"This plugin provides PHP tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-python/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="and as assert break class continue def del exec elif else except Ellipsis False finally for from global if import in is lambda not None NotImplemented or pass print raise return try True while with yield".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.python",contentTypes:["text/x-python"],patterns:[{begin:"(['\"])\\1\\1",end:"\\1\\1\\1",name:"string.quoted.triple.python"},{include:"orion.lib#string_doubleQuote"},{include:"orion.lib#string_singleQuote"},{begin:{match:"#",literal:"#"},end:{match:"$",literal:""},name:"comment.line.number-sign.python",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},
{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"#number_decimal"},{include:"orion.lib#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.python"}],repository:{number_decimal:{match:"\\b-?(?:\\.\\d+|\\d+\\.?\\d*)[lL]?\\b",name:"constant.numeric.number.python"}}});return{id:a[a.length-1].id,grammars:a,keywords:c}});e("plugins/languages/python/pythonPlugin",["orion/plugin",
"orion/editor/stylers/text_x-python/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-python","extends":"text/plain",name:"Python",extension:"py rpy pyw cpy SConstruct Sconstruct sconstruct SConscript gyp gypi".split(" ")}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Python Tool Support",version:"1.0",description:"This plugin provides Python tools support for Orion."});
a(b);b.connect()},registerServiceProviders:a}});e("plugins/languages/ruby/rubyPlugin",["orion/plugin","orion/editor/stylers/text_x-ruby/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-ruby","extends":"text/plain",name:"Ruby",extension:"rb rbx rjs Rakefile rake cgi fcgi gemspec irbrc capfile ru prawn Gemfile Guardfile Vagrantfile Appraisals Rantfile".split(" ")}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-
1])}return{connect:function(){var b=new d({name:"Orion Ruby Tool Support",version:"1.0",description:"This plugin provides Ruby tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-swift/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="associativity as class convenience deinit didSet dynamicType dynamic enum extension final func get import infix init inout internal in is lazy left let mutating none nonmutating operator optional override postfix precedence prefix private protocol Protocol public required right Self set static struct subscript typealias Type unowned var weak willSet @objc".split(" "),
a="break case continue default do else fallthrough for if return switch where while".split(" "),b=["false","nil","true"],e=["self","super"],h=["__COLUMN__","__FILE__","__FUNCTION__","__LINE__"],s=[];s.push.apply(s,d.grammars);s.push({id:"orion.swift",contentTypes:["text/x-swift"],patterns:[{include:"#string_doubleQuote"},{include:"orion.c-like#comment_singleLine"},{include:"#comment_block"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},
{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},{include:"#number_binary"},{include:"#number_hex"},{include:"#number_octal"},{include:"#number_decimal"},{include:"#keywords_operator"},{include:"#keywords_control"},{include:"#constants"},{include:"#languageVars1"},{include:"#languageVars2"}],repository:{comment_block:{begin:{match:"/\\*",literal:"/*"},end:{match:"\\*/",literal:"*/"},name:"comment.block.swift",patterns:[{include:"#comment_block"},
{match:"(\\b)(TODO)(\\b)(((?!\\*/).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task.swift"},4:{name:"comment.block.swift"}}}]},constants:{match:"(^|[^\\w`])("+b.join("|")+")\\b",captures:{2:{name:"constant.language.swift"}}},keywords_operator:{match:"(^|[^\\w`])("+c.join("|")+")\\b",captures:{2:{name:"keyword.operator.swift"}}},keywords_control:{match:"(^|[^\\w`])("+a.join("|")+")\\b",captures:{2:{name:"keyword.control.swift"}}},languageVars1:{match:"(^|[^\\w`])("+
e.join("|")+")\\b",captures:{2:{name:"variable.language.swift"}}},languageVars2:{match:"(^|[^\\w`])("+h.join("|")+")(?:$|[^\\w])",captures:{2:{name:"variable.language.swift"}}},number_binary:{match:"\\b0b[01]+\\b",name:"constant.numeric.binary.swift"},number_decimal:{match:"\\b-?(?:\\.\\d[\\d_]*|\\d[\\d_]*\\.?[\\d_]*)(?:[eE][+-]?\\d[\\d_]*)?\\b",name:"constant.numeric.decimal.swift"},number_hex:{match:"\\b0[xX](?:\\.[0-9A-Fa-f][0-9A-Fa-f_]*|[0-9A-Fa-f][0-9A-Fa-f_]*\\.?[0-9A-Fa-f_]*)(?:[pP][+-]?\\d[\\d_]*)?\\b",
name:"constant.numeric.hex.swift"},number_octal:{match:"\\b0o[01234567][01234567_]*\\b",name:"constant.numeric.octal.swift"},segment:{begin:"\\(",end:"\\)",patterns:[{include:"#segment"},{include:"#comment_block"},{include:"#number_binary"},{include:"#number_hex"},{include:"#number_octal"},{include:"#number_decimal"},{include:"#keywords_operator"},{include:"#keywords_control"},{include:"#constants"},{include:"#languageVars1"},{include:"#languageVars2"}]},string_doubleQuote:{match:'"(?:\\\\.|[^"])*"?',
name:"string.quoted.double.swift",patterns:[{begin:"\\\\\\(",end:"\\)",name:"string.interpolated.swift",patterns:[{include:"#segment"},{include:"#comment_block"},{include:"#number_binary"},{include:"#number_hex"},{include:"#number_octal"},{include:"#number_decimal"},{include:"#keywords_operator"},{include:"#keywords_control"},{include:"#constants"},{include:"#languageVars1"},{include:"#languageVars2"}]}]}}});return{id:s[s.length-1].id,grammars:s,keywords:c.concat(a).concat(b).concat(e).concat(h)}});
e("plugins/languages/swift/swiftPlugin",["orion/plugin","orion/editor/stylers/text_x-swift/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-swift","extends":"text/plain",name:"Swift",extension:["swift"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion Swift Tool Support",version:"1.0",description:"This plugin provides Swift tools support for Orion."});
a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-vb/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="AddHandler;AddressOf;Aggregate;Alias;AndAlso;And;Ansi;Assembly;Async;As;Auto;Await;Binary;Boolean;ByRef;Byte;ByVal;Call;Case;Catch;CBool;CByte;CChar;CDate;CDbl;CDec;Char;CInt;Class;CLng;CObj;Compare;Const;CShort;CSng;CStr;CType;Custom;Date;Decimal;Declare;Default;Delegate;Dim;DirectCast;Distinct;Double;Do;Each;ElseIf;Else;EndIf;End;Enum;Equals;Erase;Error;Event;Exit;Explicit;False;Finally;For;Friend;From;Function;GetType;Get;GoSub;GoTo;Group By;Group Join;Handles;If;Implements;Imports;Inherits;Integer;Interface;Into;In;IsFalse;IsTrue;Is;Iterator;Join;Key;Let;Lib;Like;Long;Loop;Me;Mid;Module;Mod;MustInherit;MustOverride;MyBase;MyClass;Namespace;New;Next;Nothing;NotInheritable;NotOverridable;Not;Object;Off;On;Optional;Option;Order By;OrElse;Or;Overloads;Overridable;Overrides;ParamArray;Preserve;Private;Property;Protected;Public;RaiseEvent;ReadOnly;ReDim;REM;RemoveHandler;Resume;Return;Select;Set;Shadows;Shared;Short;Single;Skip While;Skip;Static;Step;Stop;Strict;String;Structure;Sub;SyncLock;Take While;Take;Text;Then;Throw;To;True;Try;TypeOf;Unicode;Until;Variant;Wend;When;Where;While;WithEvents;With;WriteOnly;Xor;Yield".split(";"),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.vb",contentTypes:["text/x-vb"],patterns:[{match:"^\\s*#(?:Const|ElseIf|Else|End|ExternalSource|If|Region)\\b[^$]*",name:"meta.preprocessor.vb"},{include:"orion.lib#string_doubleQuote"},{include:"#doc"},{include:"#comment"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{include:"orion.lib#operator"},
{include:"orion.lib#number_decimal"},{include:"#number_hex"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.vb"}],repository:{comment:{begin:{match:"'",literal:"'"},end:{match:"$",literal:""},name:"comment.line.vb",patterns:[{include:"orion.lib#todo_comment_singleLine"}]},doc:{match:{match:"'''.*",literal:"'''"},name:"comment.line.documentation.vb",patterns:[{match:"\x3c[^\\s\x3e]*\x3e",name:"meta.documentation.tag"},{include:"orion.lib#todo_comment_singleLine"}]},number_hex:{match:"\x26[hH][0-9A-Fa-f]+\\b",
name:"constant.numeric.hex.vb"}}});return{id:a[a.length-1].id,grammars:a,keywords:c}});e("orion/editor/stylers/text_x-vbhtml/syntax",["orion/editor/stylers/application_xml/syntax","orion/editor/stylers/text_html/syntax","orion/editor/stylers/text_x-vb/syntax"],function(d,c,a){var b=[];b.push.apply(b,d.grammars);b.push.apply(b,c.grammars);b.push.apply(b,a.grammars);b.push({id:"orion.vbhtml",contentTypes:["text/x-vbhtml"],patterns:[{include:"#vbhtmlComment"},{include:"#codeBlock"},{include:"#expression"},
{include:"#reference"},{include:"orion.html"}],repository:{vbhtmlComment:{begin:{match:"@\\*",literal:"@*"},end:{match:"\\*@",literal:"*@"},name:"comment.block.vbhtml"},codeBlock:{begin:"(?i)^\\s*@code",end:"(?i)end code",captures:{0:{name:"entity.name.declaration.vb"}},contentName:"source.vb.embedded.vbhtml",patterns:[{include:"orion.xml#tag"},{include:"#reference"},{include:"orion.vb"}]},expression:{match:"(?i)^\\s*@(?!code)[^$]*",patterns:[{include:"#reference"},{include:"orion.vb"}]},reference:{match:"@",
name:"entity.name.declaration.vb"}}});return{id:b[b.length-1].id,grammars:b,keywords:[]}});e("plugins/languages/vb/vbPlugin",["orion/plugin","orion/editor/stylers/text_x-vb/syntax","orion/editor/stylers/text_x-vbhtml/syntax"],function(d,c,a){function b(b){b.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-vb","extends":"text/plain",name:"VB.NET",extension:["vb"]},{id:"text/x-vbhtml","extends":"text/plain",name:"vbhtml",extension:["vbhtml"]}]});b.registerServiceProvider("orion.edit.highlighter",
{},c.grammars[c.grammars.length-1]);b.registerServiceProvider("orion.edit.highlighter",{},a.grammars[a.grammars.length-1])}return{connect:function(){var a=new d({name:"Orion VB.NET Tool Support",version:"1.0",description:"This plugin provides VB.NET tools support for Orion."});b(a);a.connect()},registerServiceProviders:b}});e("plugins/languages/xml/xmlPlugin",["orion/plugin","orion/editor/stylers/application_xml/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",
{},{contentTypes:[{id:"application/xml","extends":"text/plain",name:"XML",extension:["xml","xib"],imageClass:"file-sprite-xml"},{id:"application/xhtml+xml","extends":"text/plain",name:"XHTML",extension:["xhtml","xht"],imageClass:"file-sprite-xml"}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion XML Tool Support",version:"1.0",description:"This plugin provides XML tools support for Orion."});a(b);b.connect()},
registerServiceProviders:a}});e("orion/editor/stylers/application_xquery/syntax",["orion/editor/stylers/lib/syntax"],function(d){var c="zero-digit xquery window where when version variable validate unordered union typeswitch type tumbling try treat to then text switch strip strict start stable some sliding self schema-element schema-attribute schema satisfies return processing-instruction previous preserve preceding-sibling preceding percent per-mille pattern-separator parent ordering order or option only of node no-preserve no-inherit next ne NaN namespace-node namespace module mod minus-sign lt let least le lax item is intersect instance inherit infinity in import if idiv gt grouping-separator group greatest ge function for following-sibling following external except every eq end encoding empty-sequence empty else element document-node div digit descending descendant-or-self descendant default declare decimal-separator decimal-format count copy-namespaces context construction comment collation child catch castable cast case by boundary-space base-uri attribute at ascending as and ancestor-or-self ancestor allowing".split(" "),
a=[];a.push.apply(a,d.grammars);a.push({id:"orion.xquery",contentTypes:["application/xquery"],patterns:[{include:"#comment"},{include:"#variable"},{include:"#multiLineDoubleQuote"},{include:"#multiLineSingleQuote"},{include:"orion.xml#tag"},{include:"orion.lib#brace_open"},{include:"orion.lib#brace_close"},{include:"orion.lib#bracket_open"},{include:"orion.lib#bracket_close"},{include:"orion.lib#parenthesis_open"},{include:"orion.lib#parenthesis_close"},{match:"\\b(?:"+c.join("|")+")\\b",name:"keyword.operator.js"}],
repository:{comment:{begin:{match:"\\(:",literal:"(:"},end:{match:":\\)",literal:":)"},name:"comment.block.xquery",patterns:[{match:"(\\b)(TODO)(\\b)(((?!:\\)).)*)",name:"meta.annotation.task.todo",captures:{2:{name:"keyword.other.documentation.task"},4:{name:"comment.block"}}}]},variable:{match:"\\$[a-zA-z0-9_]+",name:"variable.other.xquery"},multiLineDoubleQuote:{begin:'"',end:'"',name:"string.quoted.double"},multiLineSingleQuote:{begin:"'",end:"'",name:"string.quoted.single"}}});return{id:a[a.length-
1].id,grammars:a,keywords:c}});e("plugins/languages/xquery/xqueryPlugin",["orion/plugin","orion/editor/stylers/application_xquery/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"application/xquery","extends":"text/plain",name:"XQuery",extension:["xq","xqy","xquery"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion XQuery Tool Support",version:"1.0",
description:"This plugin provides XQuery tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("orion/editor/stylers/text_x-yaml/syntax",[],function(){var d=["false","null","true"],c="!!bool !!float !!int !!map !!null !!omap !!seq !!str".split(" ");return{id:"orion.yaml",grammars:[{id:"orion.yaml",contentTypes:["text/x-yaml"],patterns:[{include:"#numberSignComment"},{match:"^%(?:YAML|TAG)\\s.*",name:"meta.directive.yaml"},{begin:"^.*?:(?:[\\t ]|$)",end:"$",contentName:"string.unquoted.yaml",
beginCaptures:{0:{name:"entity.name.key.yaml"}},patterns:[{include:"#numberSignComment"},{match:"^\\s*[\x26*]\\s*$",name:"entity.name.tag.yaml"},{match:"(?i)^\\s*(?:"+d.join("|")+")\\s*$",name:"keyword.operator.yaml"},{match:"(?i)^\\s*(?:"+c.join("|")+")\\b",name:"keyword.operator.yaml"},{match:"(?i)^\\s*(?:-?[0-9]*(?:\\.[0-9]+)?(?:e[-+][1-9][0-9]*)?)\\s*$",name:"constant.numeric.yaml"},{match:"(?i)^\\s*(?:-?[1-9][0-9]*|0|-?\\.inf|\\.nan)\\s*$",name:"constant.numeric.yaml"}]},{match:"---|\\.\\.\\.",
name:"meta.separator.yaml"}],repository:{numberSignComment:{begin:{match:"(?:^|\\s)#",literal:"#"},end:{match:"$",literal:""},name:"comment.line.number-sign.yaml",patterns:[{include:"orion.lib#todo_comment_singleLine"}]}}}],keywords:c.concat(d)}});e("plugins/languages/yaml/yamlPlugin",["orion/plugin","orion/editor/stylers/text_x-yaml/syntax"],function(d,c){function a(a){a.registerServiceProvider("orion.core.contenttype",{},{contentTypes:[{id:"text/x-yaml","extends":"text/plain",name:"YAML",extension:["yaml",
"yml"]}]});a.registerServiceProvider("orion.edit.highlighter",{},c.grammars[c.grammars.length-1])}return{connect:function(){var b=new d({name:"Orion YAML Tool Support",version:"1.0",description:"This plugin provides YAML tools support for Orion."});a(b);b.connect()},registerServiceProviders:a}});e("plugins/languageToolsPlugin","orion/plugin plugins/languages/arduino/arduinoPlugin plugins/languages/c/cPlugin plugins/languages/cpp/cppPlugin plugins/languages/csharp/csharpPlugin plugins/languages/docker/dockerPlugin plugins/languages/erlang/erlangPlugin plugins/languages/go/goPlugin plugins/languages/haml/hamlPlugin plugins/languages/jade/jadePlugin plugins/languages/java/javaPlugin plugins/languages/launch/launchPlugin plugins/languages/lua/luaPlugin plugins/languages/markdown/markdownPlugin plugins/languages/objectiveC/objectiveCPlugin plugins/languages/php/phpPlugin plugins/languages/python/pythonPlugin plugins/languages/ruby/rubyPlugin plugins/languages/swift/swiftPlugin plugins/languages/vb/vbPlugin plugins/languages/xml/xmlPlugin plugins/languages/xquery/xqueryPlugin plugins/languages/yaml/yamlPlugin".split(" "),
function(d){function c(b){a.forEach(function(a){a.registerServiceProviders(b)})}var a=Array.prototype.slice.call(arguments);a.shift();return{connect:function(){var a=new d({name:"Orion Languages Tool Support",version:"1.0",description:"This plugin provides tooling for languages that are not included in other core Orion plugins."});c(a);a.connect()},registerServiceProviders:c}});e("plugins/webEditingPlugin",["orion/plugin","i18n!orion/nls/messages"],function(d,c){function a(a){a.registerService("orion.core.contenttype",
{},{contentTypes:[{id:"text/plain",name:"Text",extension:["txt"],imageClass:"file-sprite-text modelDecorationSprite"},{id:"application/xml","extends":"text/plain",name:"XML",extension:["xml"],imageClass:"file-sprite-xml modelDecorationSprite"},{id:"text/x-markdown","extends":"text/plain",name:"Markdown",extension:["md"]},{id:"text/conf","extends":"text/plain",name:"Conf",extension:["conf"]},{id:"text/sh","extends":"text/plain",name:"sh",extension:["sh"]},{id:"application/pdf","extends":"application/browser-renderable",
name:"PDF",extension:["pdf"]},{id:"application/octet-stream",name:"octet-stream",extension:["exe","bin","doc","ppt"]},{id:"application/zip","extends":"application/octet-stream",name:"ZIP",extension:["war","jar","zip","rar"]},{id:"image/gif",name:"GIF",extension:["gif"],imageClass:"file-sprite-image modelDecorationSprite"},{id:"image/jpeg",name:"JPG",extension:["jpg","jpeg","jpe"],imageClass:"file-sprite-image modelDecorationSprite"},{id:"image/ico",name:"ICO",extension:["ico"],imageClass:"file-sprite-image modelDecorationSprite"},
{id:"image/png",name:"PNG",extension:["png"],imageClass:"file-sprite-image modelDecorationSprite"},{id:"image/tiff",name:"TIFF",extension:["tif","tiff"],imageClass:"file-sprite-image modelDecorationSprite"},{id:"image/svg",name:"SVG",extension:["svg"],imageClass:"file-sprite-image modelDecorationSprite"}]});a.registerService("orion.edit.editor",{},{id:"orion.editor","default":!0,name:c["Orion Editor"],nls:"orion/nls/messages",uriTemplate:"../edit/edit.html#{,Location,params*}",orionTemplate:"../edit/edit.html#{,Location,params*}",
validationProperties:[{source:"!Projects"}]});a.registerService("orion.navigate.openWith",{},{editor:"orion.editor",excludedContentTypes:["image/*","application/zip"]});a.registerService("orion.edit.editor",{},{id:"orion.viewer.markdown",name:c["Orion Markdown Viewer"],nls:"orion/nls/messages",uriTemplate:"../edit/edit.html#{,Location,params*},editor\x3dorion.viewer.markdown"});a.registerService("orion.navigate.openWith",{},{editor:"orion.viewer.markdown",contentType:["text/x-markdown"]});a.registerService("orion.edit.editor",
{},{id:"orion.editor.markdown",name:c["Orion Markdown Editor"],nls:"orion/nls/messages","default":!0,uriTemplate:"../edit/edit.html#{,Location,params*},editor\x3dorion.editor.markdown"});a.registerService("orion.navigate.openWith",{},{editor:"orion.editor.markdown",contentType:["text/x-markdown"]});a.registerService("orion.edit.editor",{},{id:"orion.viewer.raw",name:c.Browser,nls:"orion/nls/messages",uriTemplate:"{+Location}",validationProperties:[{source:"!Projects"}]})}return{connect:function(){var b=
new d({name:"Orion Web Editing Plugin",version:"1.0",description:"This plugin provides editor link support for the navigator."});a(b);b.connect()},registerServiceProviders:a}});e("plugins/embeddedToolingPlugin",["orion/plugin","plugins/languageToolsPlugin","plugins/webEditingPlugin"],function(d){function c(){var b=new d;b.updateHeaders({name:"Pluggable editor tooling support",version:"1.0",description:"This plugin provides the core language tooling support for the Orion pluggable editor."});a(b);
b.connect()}function a(a){b.forEach(function(b){b.registerServiceProviders(a)})}var b=Array.prototype.slice.call(arguments);b.shift();c();return{connect:c,registerServiceProviders:a}});return x("plugins/embeddedToolingPlugin")});